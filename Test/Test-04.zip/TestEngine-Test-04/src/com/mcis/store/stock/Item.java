package com.mcis.store.stock;

public class Item {
	
}
