package com.mcis.netbanking;

public class Transaction {

}
